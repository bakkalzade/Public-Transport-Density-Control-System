package sample;

public interface Icontrol {//implemented by controller class

    private static void CreateStops() { }
    private static void CreateBus(){ }
    private static void removePassOnStop(Bus bus){}
    private static void addPassOnStop(Bus bus, Stop stop){}
    private void salih(){}

}
