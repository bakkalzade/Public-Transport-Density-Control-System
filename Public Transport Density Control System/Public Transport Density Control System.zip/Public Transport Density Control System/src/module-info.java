module busProject {
    requires javafx.fxml;
    requires javafx.controls;
    requires com.jfoenix;

    opens sample;
}